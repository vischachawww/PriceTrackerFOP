/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package l7;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**@author AmnaSurayaHalim 22002801/2
 * write statements that replace each line of a text file with its reverse and save it to a new text file name reverse.txt.

 */
public class L7Q3 {
    public static void main(String[] args) {
        //write to text file
        Scanner scan=new Scanner(System.in);
        System.out.print("Enter sentecne:");
        String userInput=scan.nextLine();
        try{
            PrintWriter writeText=new PrintWriter(new FileOutputStream("C:\\Users\\User\\Documents\\NetBeansProjects\\L7\\final retry\\original.txt.txt"));
            writeText.println("sandwich wakuku");
            writeText.println("ORIGINAL SENTENCE");
            writeText.println(userInput);
            writeText.close();
        }catch(FileNotFoundException e){
            System.out.println("file not ofund");
        }catch(IOException e){
            System.out.println("smtg wrong w file output");
        }
        //read txt file and reverse it and print the output
         try{
            Scanner readText=new Scanner(new FileInputStream("C:\\Users\\User\\Documents\\NetBeansProjects\\L7\\final retry\\original.txt.txt"));
            PrintWriter toReverse= new PrintWriter(new FileOutputStream("C:\\Users\\User\\Documents\\NetBeansProjects\\L7\\final retry\\rereverse.txt.txt"));
            
            while(readText.hasNextLine()){
                String line=readText.nextLine();
                System.out.println(line); //guna sout sbb ni read text file
                String reversed=reverseString(line);
                toReverse.println(reversed); //use println je sbb ni nk sout using write text printwriter
                System.out.println(reversed);
            }
            readText.close();
            toReverse.close();
        }catch(FileNotFoundException e){
            System.out.println("file not ofund");
        }catch(IOException e){
            System.out.println("smtg wrong w  output");
        }
         
    }
    public static String reverseString(String line){
        char[] character = line.toCharArray();
        int start=0;
        int end=character.length-1;
        //selagi length lgi besar dri 0, dia akan go thro and swapped each char
        //in while loop
        while(end>start){
            char temp=character[start];
            character[start]=character[end];
            character[end]=temp;
            start++;
            end--;
        }
        //in for loop
        for(;end>start;start++,end--){
            char temp=character[start];
            character[start]=character[end];
            character[end]=temp;
        }
        
        return new String(character);
    }
}

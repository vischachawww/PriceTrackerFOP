/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package l7;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Scanner;

/**Write a program that store the table below in a binary file name
 * coursename.dat. Then, ask the users to enter a course code. 
 * The program will display the course name from coursename.dat.

 */
public class L7 {
    public static void main(String[] args) {
        String[][] table={
            {"Course code","Course Name"},
            {"WXES1116","PROGRAMMING 1"},
            {"WXES1115","DATA STRUCTURE"},
            {"WXES1110","OPERATING SYSTEM"},
            {"WXES1112","COMPUTING MATHEMATICS 1"}
        };
        try{ //file tu mcm tkleh je letak "coursename.dat", must put directory
           ObjectOutputStream storebinary= new ObjectOutputStream(new FileOutputStream("C:\\Users\\User\\Documents\\NetBeansProjects\\L7\\coursenamess.dat"));
           //the int rows and column is important sbb nak output a box instead of a long string
           //without it nnti susah nk control 
           int rows=table.length;
           int columns=table[0].length;
           storebinary.writeInt(rows);
           storebinary.writeInt(columns);
           for(int i=0; i<rows;i++){
               for(int j=0;j<columns;j++){
                   storebinary.writeUTF(table[i][j]);
               }
           }
            storebinary.close();
        }catch(FileNotFoundException e){
            System.out.println("File not found");
        }catch(IOException e){
            System.out.println("Problem with file output ");
        }
        Scanner input= new Scanner(System.in);
        System.out.print("Enter a course code: ");
        String courseCode=input.nextLine();
        //read .dat binary file
        try{
            ObjectInputStream readbinary= new ObjectInputStream(new FileInputStream("coursenamess.dat"));
          
                int rows=table.length;
                int columns=table[0].length;
              
                System.out.println("COURSE TABLE");
                for(int i=0; i<rows;i++){
               for(int j=0;j<columns;j++){
                   System.out.print(table[i][j]+"\t");
               }
                    System.out.println(); //**penting nk bgi dia tk satu line je lol
           }
            //nk display coursename dri user input
            
            System.out.println("Course Code: "+courseCode);
            for(int i=0; i<rows;i++){
               for(int j=0;j<columns;j++){
                  if(table[i][0].equals(courseCode)){
                      int temp=j;
                      System.out.println("Course Name: "+table[i][temp]);
                  }else{
                      System.out.println("course code not found");
                  }
               }
            }
            
            readbinary.close();
            
        }catch (FileNotFoundException e){
            System.out.println("File was not found: "+e.getMessage());
        }catch(IOException e){
            System.out.println("file output wrong");
        }
    }
}
    
   
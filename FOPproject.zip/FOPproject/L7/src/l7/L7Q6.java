/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package l7;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

/**@author AmnaSurayaHalim 22002801
 * display the ProductID, ProductName, OrderQuantity, PricePerUnit and TotalPrice for each order
 */
public class L7Q6 {
    public static void main(String[] args) {
       //merge data from 2 text file
       //read txt file
        System.out.println("ProductID \t Product Name \t\t Quantity \t PricePerUnit \t Total");
       try{
           Scanner orda=new Scanner(new FileInputStream("C:\\Users\\User\\Downloads\\Lab07 (1)\\Lab07\\order.txt"));

           String[] order,product;
           String temp, productName="";
           int quantity=0;
           double price=0;
           //file order
           while(orda.hasNextLine()){
                temp=orda.nextLine();
                order=temp.split(",");
                quantity=Integer.parseInt(order[2]);
               //System.out.println(quantity);
           
           
                //file product
                Scanner cs=new Scanner(new FileInputStream("C:\\Users\\User\\Downloads\\Lab07 (1)\\Lab07\\product.txt"));

                while(cs.hasNextLine()){
                    temp=cs.nextLine();
                    product=temp.split(","); //to categorise array into column by ,

                    //System.out.println(Arrays.toString(product));
                   if(order[1].equals(product[0])){
                       productName=product[1];
                       price=Double.parseDouble(product[2]);
                       break;
                    }
                }
           cs.close();
           System.out.printf("%-10s%-25s", order[1], productName);
           System.out.printf("%-10d%-14.2f%-7.2f\n", quantity, price, quantity * price);

         }   
          orda.close();
          
       }catch(FileNotFoundException e){
           System.out.println("file was not found");
       }catch(IOException e){
           System.out.println("output error");
       }
    }
}

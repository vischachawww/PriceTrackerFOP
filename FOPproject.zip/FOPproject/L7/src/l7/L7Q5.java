/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package l7;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.ObjectInputStream;
/**@author AmnaSurayaHalim 22002801/2*/
public class L7Q5 {
    public static void main(String[] args) {
        try {
            ObjectInputStream cs = new ObjectInputStream (new FileInputStream("C:\\Users\\User\\Downloads\\Lab07\\Lab07\\person.dat"));
            // Modify the next line based on your actual data structure
            int totalrecord= cs.readInt();
            System.out.println("Total number of records: "+totalrecord);
            
            try{
                // Print header
                    System.out.println("Name\t\tAge\tGender");
                    System.out.println("------------------------------");

               // Read the data into arrays for sorting
                String[] name = new String[totalrecord];
                int[] age = new int[totalrecord];
                char[] gender = new char[totalrecord];

                for (int i = 0; i < totalrecord; i++) {
                    name[i] = cs.readUTF();
                    age[i] = cs.readInt();
                    gender[i] = cs.readChar();
                }
                     // Sort the data based on the "Name" column in ascending order
                    for (int i = 0; i < totalrecord - 1; i++) {
                        for (int j = 0; j < totalrecord - i - 1; j++) {
                            if (name[j].compareTo(name[j + 1]) > 0) {
                                // Swap if needed
                                 // Swap names
                            String tempName = name[j];
                            name[j] = name[j + 1];
                            name[j + 1] = tempName;

                            // Swap ages
                            int tempAge = age[j];
                            age[j] = age[j + 1];
                            age[j + 1] = tempAge;

                            // Swap genders
                            char tempGender = gender[j];
                            gender[j] = gender[j + 1];
                            gender[j + 1] = tempGender;
                            }
                        }
                        }
                    for (int i = 0; i < totalrecord; i++) {
                        System.out.println(name[i] + "\t" + age[i] + "\t" + gender[i]);

                    }
                    
            }catch (EOFException e){
                System.out.println("\nFinish reading files.");
            }
            cs.close();
     } catch (FileNotFoundException e) {
        System.out.println("File was not found"); 
     } catch (IOException e) {
        System.out.println("Problem with file input.");
     }
    }
  


}

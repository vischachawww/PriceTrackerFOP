/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package l7;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**@author AmnaSurayaHalim 22002801/2
 * display the number of characters, words and lines in a text file. 
 * Assume that each word is separated by one space character.
 */
public class L7Q4 {
    public static void main(String[] args) {
        Scanner cs=new Scanner(System.in);
       /// System.out.print("write smtg: ");
       // String text=cs.nextLine();
        //write to text file===cancel sbb to write with lines kene guna stringbuilder
        
        try{
            //PrintWriter write=new PrintWriter(new FileOutputStream("C:\\Users\\User\\Documents\\NetBeansProjects\\L7\\final retry\\trytestq4.txt"));
                //store the user input inside txt file
               // write.println(text);
            //read the text file to keluarkan number of character, etc
            Scanner read=new Scanner(new FileInputStream("C:\\Users\\User\\Documents\\NetBeansProjects\\L7\\final retry\\trytestq4.txt"));
            while(read.hasNextLine()){
                int character=0;
                int word=0;
                int line=0;
                while(read.hasNextLine()){
                    String sentence=cs.nextLine();
                    line++;
                    String[] words=sentence.split(" ");
                    word+=words.length;
                    for(int i=0; i<words.length;i++){
                        character+=words[i].length();
                    }
                }
                System.out.println("number of character: "+character);
                System.out.println("number of word: "+word);
                System.out.println("number of line: "+line);
            }
                
               read.close();
            
        }catch(FileNotFoundException e){
            System.out.println("file no foudm");
        }catch(IOException e){
            System.out.println("outptut wrong");
        }
        

    }
}

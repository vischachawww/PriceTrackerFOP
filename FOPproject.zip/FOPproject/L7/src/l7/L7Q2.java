/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package l7;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;
import java.net.URL;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.URLConnection;
public class L7Q2 {
    public static void main(String[] args) {
        //read content of a webpage
        try{
            URL u=new URL("https://fsktm.um.edu.my/");
            URLConnection cnn=u.openConnection();
            InputStream stream=cnn.getInputStream();
            Scanner in=new Scanner(stream);
            //write to text file
            //dont need to do another try catch sbb scanner input for url ada dlm ni
            //so kalau buat, tk dpt that access to 'in'
            PrintWriter writeText=new PrintWriter(new FileOutputStream("C:\\Users\\User\\Documents\\NetBeansProjects\\L7\\index.htm.txt"));
            while(in.hasNext()){
                writeText.println(in.nextLine());
            }
            writeText.close();
         
        }catch(FileNotFoundException e){
            System.out.println("file not found");
        }catch(IOException e){
            System.out.println("IO Error: "+e.getMessage());
        }
        
        
    }
}
        
       
